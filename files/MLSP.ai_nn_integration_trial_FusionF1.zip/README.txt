*************************************************************
For evaluation only, no commercial use. 
MLSP.ai
*************************************************************

Please refer to header file for processing function definition. 

ISA related headers need to be visible to compiler. 
<xtensa/config/core-isa.h>
<xtensa/tie/xt_core.h>
<xtensa/tie/xt_hifi3.h>
<xtensa/tie/xt_fusion.h>
<xtensa/tie/xt_misc.h>
