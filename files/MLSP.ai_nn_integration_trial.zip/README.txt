*************************************************************
For evaluation only, no commercial use. 
MLSP.ai
*************************************************************

Please refer to header file for processing function definition. 
Here is a build example:

test build command ******************************************

arm-none-eabi-gcc.exe main.c -o main.out -L. -lmodel_processing -g -Ofast -mcpu=cortex-m7 --specs=nosys.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb


main.c ******************************************************

#include <stdint.h>

#include "model_frame_proc.h"

int main(void)
{
    int16_t test_data[64];
    int16_t test_buf[1024];
       
    model_frame_proc(test_data, test_buf);
    
    return 1;
}