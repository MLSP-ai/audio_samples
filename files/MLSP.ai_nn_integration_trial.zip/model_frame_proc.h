/*
 *  Model frame processing function
 *  Input: 
 *      p_data_int16: pointer to input data, 64 PCM samples in Q15 format
 *      p_tmp_buffer: pionter to temp working buffer, size should be 1k int16,
 *                    keep consistent during stream processing
 *  Output:
 *      p_data_int16: pointer to output data, 64 PCM samples in Q15 format
 */
 
void model_frame_proc(int16_t *p_data_int16, int16_t *p_tmp_buffer);
